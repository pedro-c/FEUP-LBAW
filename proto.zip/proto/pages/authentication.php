<?php


include_once '../config/init.php';

$smarty->display($BASE_DIR . 'templates/authentication/authentication.tpl');
