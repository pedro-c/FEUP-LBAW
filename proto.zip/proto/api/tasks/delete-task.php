<?php
include_once('../../database/tasks.php');

if (isset($_POST['action'])) {
    if ($_POST['action'] == 'delete-task') {

    }
}