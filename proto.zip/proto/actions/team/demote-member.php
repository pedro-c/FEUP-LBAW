<?php
include_once('../../config/init.php');
include_once('../../database/team.php');

$project_id = $_POST['idProject'];
$user_id = $_POST['idUser'];
//TODO Function that demotes member
 ?>
